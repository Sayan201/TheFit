# FireBolt Sync (prototype)

A modern, ad-free Android starter app for a Fire-Boltt 215 fitness band.

## Current prototype features
- Modern dashboard UI inspired by minimalist fitness apps
- BLE device scan and list of nearby devices
- No advertising or analytics SDKs
- Build workflow to compile a debug APK in GitHub Actions

## Not implemented yet
This is **not yet a working fitness-data sync app**. The Fire-Boltt/DaFit proprietary BLE command protocol has not been decoded or validated. Device selection currently reports a status message; it does not pair, decode readings, or sync records.
Health Connect writing, historical sync, background sync, sleep, SpO2, exercise and heart-rate import remain to be implemented and tested.

## Build APK in GitHub Actions
1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository root (not the parent folder).
3. Open **Actions** and enable workflows if GitHub asks.
4. Run **Build FireBolt Sync APK** using **Run workflow**, or push to `main`.
5. Open the completed workflow run, find **Artifacts**, and download `FireBoltSync-debug-apk`.
6. Extract the ZIP; install `app-debug.apk` on your Android phone. You may need to allow installation from that source.

## Requirements
- Android 8.0+ (API 26+), BLE hardware for scanning
- Android Studio / Android SDK for local builds, or GitHub Actions for cloud builds

## Privacy
The prototype has no network permission and contains no ad or analytics dependencies. BLE scan results are held in app memory only.
