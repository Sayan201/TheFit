package com.fireboltsync.app

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Mint = Color(0xFF36C98F)
private val Ink = Color(0xFF17211F)
private val Muted = Color(0xFF737D7A)
private val Canvas = Color(0xFFF5F7F6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FireBoltSyncApp(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FireBoltSyncApp(activity: MainActivity) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var scanning by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Not connected") }
    var devices by remember { mutableStateOf(listOf<String>()) }
    var permissionReady by remember { mutableStateOf(false) }

    val permissions = remember {
        if (Build.VERSION.SDK_INT >= 31) arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT
        ) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        permissionReady = result.values.all { it }
        if (!permissionReady) status = "Bluetooth permission is required to scan"
    }

    val adapter = remember {
        (activity.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    }

    val scanCallback = remember {
        object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val label = try {
                    result.device.name ?: result.scanRecord?.deviceName ?: "Unknown BLE device"
                } catch (_: SecurityException) { "BLE device" }
                val address = try { result.device.address } catch (_: SecurityException) { "" }
                val row = "$label${if (address.isNotBlank()) " · $address" else ""}"
                devices = (devices + row).distinct().take(30)
                if (label.contains("Fire", true) || label.contains("Moy", true) ||
                    label.contains("DaFit", true)) status = "Possible watch found — tap device to select"
            }
            override fun onScanFailed(errorCode: Int) {
                scanning = false
                status = "Scan failed ($errorCode). Check Bluetooth and permissions."
            }
        }
    }

    fun startScan() {
        if (!permissions.all { ContextCompat.checkSelfPermission(activity, it) == PackageManager.PERMISSION_GRANTED }) {
            permissionLauncher.launch(permissions)
            return
        }
        if (adapter == null || !adapter.isEnabled) {
            status = "Turn on Bluetooth, then scan again"
            return
        }
        try {
            devices = emptyList()
            status = "Scanning nearby BLE devices…"
            scanning = true
            adapter.bluetoothLeScanner.startScan(scanCallback)
            android.os.Handler(mainLooper).postDelayed({
                try { adapter.bluetoothLeScanner?.stopScan(scanCallback) } catch (_: Exception) {}
                scanning = false
                if (devices.isEmpty()) status = "No devices found. Keep the watch awake and retry."
                else status = "Found ${devices.size} device(s). Protocol connection is not implemented yet."
            }, 12000)
        } catch (_: SecurityException) {
            scanning = false
            status = "Bluetooth permission denied"
        } catch (e: Exception) {
            scanning = false
            status = "Could not start scan: ${e.message ?: "unknown error"}"
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Mint, onPrimary = Color.White, background = Canvas,
            surface = Color.White, onSurface = Ink, secondary = Color(0xFF7A72E8)
        )
    ) {
        Scaffold(
            containerColor = Canvas,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 },
                        icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 },
                        icon = { Icon(Icons.Default.Favorite, null) }, label = { Text("Health") })
                    NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 },
                        icon = { Icon(Icons.Default.Watch, null) }, label = { Text("Device") })
                    NavigationBarItem(selected = selectedTab == 3, onClick = { selectedTab = 3 },
                        icon = { Icon(Icons.Default.Sync, null) }, label = { Text("Sync") })
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 20.dp, bottom = 22.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                when (selectedTab) {
                                    1 -> "Your health"
                                    2 -> "Your device"
                                    3 -> "Health sync"
                                    else -> "Good morning"
                                },
                                fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Ink
                            )
                            Text("Move well. Feel better.", color = Muted, fontSize = 14.sp)
                        }
                        Surface(shape = CircleShape, color = Color.White) {
                            IconButton(onClick = { status = "FireBolt Sync · Version 0.1.0" }) {
                                Icon(Icons.Default.Settings, "Settings", tint = Ink)
                            }
                        }
                    }
                }

                item {
                    Surface(shape = RoundedCornerShape(24.dp), color = Color.White, shadowElevation = 1.dp) {
                        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(shape = CircleShape, color = Color(0xFFE7F8F0), modifier = Modifier.size(52.dp)) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Watch, null, tint = Mint, modifier = Modifier.size(29.dp))
                                    }
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("Fire-Boltt 215", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                                    Text(status, fontSize = 12.sp, color = Muted)
                                }
                                Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFFE8F8F0)) {
                                    Text(if (scanning) "Scanning" else "BLE", color = Color(0xFF16855A),
                                        fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp))
                                }
                            }
                            Button(onClick = { startScan() }, modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Ink)) {
                                Icon(if (scanning) Icons.Default.BluetoothSearching else Icons.Default.Bluetooth, null)
                                Spacer(Modifier.width(8.dp))
                                Text(if (scanning) "Searching for devices…" else "Find my watch")
                            }
                            Text("Firmware: MOV-70D2-2.0.1", color = Muted, fontSize = 12.sp)
                        }
                    }
                }

                if (devices.isNotEmpty()) {
                    item { SectionTitle("Nearby Bluetooth devices") }
                    items(devices) { device ->
                        Surface(shape = RoundedCornerShape(14.dp), color = Color.White, onClick = {
                            status = "Selected $device. Pairing and data protocol are not implemented yet."
                        }) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Bluetooth, null, tint = Mint)
                                Spacer(Modifier.width(10.dp))
                                Text(device, modifier = Modifier.weight(1f), fontSize = 13.sp)
                                Icon(Icons.Default.ChevronRight, null, tint = Muted)
                            }
                        }
                    }
                }

                if (selectedTab == 0 || selectedTab == 1) {
                    item { SectionTitle("Today at a glance") }
                    item {
                        Surface(shape = RoundedCornerShape(24.dp), color = Color.White, shadowElevation = 1.dp) {
                            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(shape = CircleShape, color = Color(0xFFE4F8EE), modifier = Modifier.size(44.dp)) {
                                        Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.DirectionsWalk, null, tint = Mint) }
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text("Steps", color = Muted, fontSize = 13.sp)
                                        Text("—", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Text("of 10,000", color = Muted, fontSize = 12.sp)
                                }
                                Spacer(Modifier.height(14.dp))
                                LinearProgressIndicator(progress = { 0f }, modifier = Modifier.fillMaxWidth().height(7.dp),
                                    color = Mint, trackColor = Color(0xFFE8EEEB))
                                Spacer(Modifier.height(8.dp))
                                Text("Connect your watch to load real measurements", color = Muted, fontSize = 12.sp)
                            }
                        }
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            MetricCard("Heart rate", "— bpm", Icons.Default.Favorite, Color(0xFFFFE8ED), Modifier.weight(1f))
                            MetricCard("Sleep", "—", Icons.Default.DarkMode, Color(0xFFECEAFF), Modifier.weight(1f))
                        }
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            MetricCard("Blood oxygen", "—%", Icons.Default.WaterDrop, Color(0xFFE2F8FA), Modifier.weight(1f))
                            MetricCard("Exercise", "— min", Icons.Default.DirectionsRun, Color(0xFFE6F8EA), Modifier.weight(1f))
                        }
                    }
                }

                if (selectedTab == 2) {
                    item { SectionTitle("Device settings") }
                    item { InfoRow(Icons.Default.BatteryFull, "Battery", "Available after protocol integration") }
                    item { InfoRow(Icons.Default.Sync, "Last sync", "Not synced yet") }
                    item { InfoRow(Icons.Default.Bluetooth, "Connection", "BLE scan prototype") }
                }

                if (selectedTab == 3) {
                    item { SectionTitle("Health Connect") }
                    item {
                        Surface(shape = RoundedCornerShape(22.dp), color = Color.White) {
                            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Icon(Icons.Default.Favorite, null, tint = Mint, modifier = Modifier.size(32.dp))
                                Text("Sync your health data", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                Text("Health Connect writing will be added after the device data format is validated. No data is uploaded by this prototype.",
                                    color = Muted, fontSize = 13.sp)
                                OutlinedButton(onClick = { status = "Health Connect integration is not active in this prototype." },
                                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                                    Text("Check sync setup")
                                }
                            }
                        }
                    }
                }
                item {
                    Text("Private by design · No ads · No analytics", color = Muted, fontSize = 12.sp,
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
}

@Composable
private fun MetricCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector,
                       tint: Color, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, shape = RoundedCornerShape(22.dp), color = Color.White, shadowElevation = 1.dp) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Surface(shape = CircleShape, color = tint, modifier = Modifier.size(38.dp)) {
                Box(contentAlignment = Alignment.Center) { Icon(icon, null, tint = Ink, modifier = Modifier.size(20.dp)) }
            }
            Text(title, color = Muted, fontSize = 12.sp)
            Text(value, color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun InfoRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, detail: String) {
    Surface(shape = RoundedCornerShape(16.dp), color = Color.White) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Mint)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(detail, color = Muted, fontSize = 12.sp)
            }
        }
    }
}
